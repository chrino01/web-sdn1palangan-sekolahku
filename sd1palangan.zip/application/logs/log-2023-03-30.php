<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-03-30 03:21:03 --> 404 Page Not Found: Media_library/images
ERROR - 2023-03-30 03:21:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2023-03-30 03:21:27 --> 404 Page Not Found: Assets/plugins
