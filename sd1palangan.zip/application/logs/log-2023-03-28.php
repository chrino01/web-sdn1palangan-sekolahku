<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-03-28 03:22:38 --> 404 Page Not Found: Media_library/images
ERROR - 2023-03-28 05:58:54 --> 404 Page Not Found: Media_library/images
