<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-03-21 05:02:11 --> 404 Page Not Found: Media_library/images
