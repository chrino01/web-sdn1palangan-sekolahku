<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-04-28 16:23:40 --> 404 Page Not Found: Media_library/images
