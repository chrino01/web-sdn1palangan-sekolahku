<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-02-13 16:09:11 --> 404 Page Not Found: Media_library/images
