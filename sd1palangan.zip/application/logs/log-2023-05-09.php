<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-09 04:11:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\sd1palangan\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-05-09 04:11:09 --> Unable to connect to the database
ERROR - 2023-05-09 04:23:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\sd1palangan\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-05-09 04:23:00 --> Unable to connect to the database
ERROR - 2023-05-09 04:25:23 --> 404 Page Not Found: Media_library/posts
ERROR - 2023-05-09 04:25:23 --> 404 Page Not Found: Media_library/images
ERROR - 2023-05-09 04:28:57 --> 404 Page Not Found: Media_library/posts
ERROR - 2023-05-09 04:28:58 --> 404 Page Not Found: Media_library/images
ERROR - 2023-05-09 06:12:49 --> 404 Page Not Found: Media_library/posts
ERROR - 2023-05-09 06:12:50 --> 404 Page Not Found: Media_library/images
