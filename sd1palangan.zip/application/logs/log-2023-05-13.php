<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-13 15:22:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\sd1palangan\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-05-13 15:22:43 --> Unable to connect to the database
