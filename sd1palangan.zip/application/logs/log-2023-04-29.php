<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-04-29 04:58:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\sd1palangan\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-04-29 04:58:35 --> Unable to connect to the database
ERROR - 2023-04-29 05:24:31 --> 404 Page Not Found: Media_library/images
