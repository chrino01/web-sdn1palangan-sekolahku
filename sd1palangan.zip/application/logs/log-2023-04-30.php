<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-04-30 15:44:50 --> 404 Page Not Found: Media_library/images
ERROR - 2023-04-30 19:15:37 --> 404 Page Not Found: Media_library/images
